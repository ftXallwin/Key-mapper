plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.keymapper"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.example.keymapper"
        minSdk = 24          // gestures need API 24+; pure Kotlin, so runs on 32-bit ARMv7
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
