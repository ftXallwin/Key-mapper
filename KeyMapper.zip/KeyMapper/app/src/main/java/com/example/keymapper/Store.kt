package com.example.keymapper

import android.content.Context

object Store {
    private fun p(c: Context) = c.getSharedPreferences("profiles", 0)

    fun profiles(c: Context): List<String> = p(c).getString("names", "Default")!!.split("|")
    fun current(c: Context): String = p(c).getString("cur", "Default")!!
    fun setCurrent(c: Context, n: String) = p(c).edit().putString("cur", n).apply()

    fun addProfile(c: Context, n: String) {
        val name = n.trim().replace("|", "").ifEmpty { return }
        val all = (profiles(c) + name).distinct()
        p(c).edit().putString("names", all.joinToString("|")).putString("cur", name).apply()
    }

    fun deleteCurrent(c: Context) {
        val all = profiles(c); if (all.size < 2) return
        val cur = current(c); val rest = all - cur
        p(c).edit().remove("m_$cur").remove("s_$cur")
            .putString("names", rest.joinToString("|")).putString("cur", rest[0]).apply()
    }

    // Button map: "keyCode:x:y;keyCode:x:y"
    fun load(c: Context): MutableMap<Int, Pair<Float, Float>> {
        val out = linkedMapOf<Int, Pair<Float, Float>>()
        (p(c).getString("m_" + current(c), "") ?: "").split(";").filter { it.isNotBlank() }.forEach {
            val a = it.split(":"); out[a[0].toInt()] = Pair(a[1].toFloat(), a[2].toFloat())
        }
        return out
    }
    fun save(c: Context, m: Map<Int, Pair<Float, Float>>) {
        val s = m.entries.joinToString(";") { "${it.key}:${it.value.first}:${it.value.second}" }
        p(c).edit().putString("m_" + current(c), s).apply()
    }

    // Joystick area: centerX, centerY, radius
    fun stick(c: Context): FloatArray? =
        p(c).getString("s_" + current(c), null)?.split(":")?.map { it.toFloat() }?.toFloatArray()
    fun saveStick(c: Context, cx: Float, cy: Float, r: Float) =
        p(c).edit().putString("s_" + current(c), "$cx:$cy:$r").apply()

    // Tiny on-device log so problems can be read inside the app (no computer needed)
    fun log(c: Context, msg: String) {
        val t = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US).format(java.util.Date())
        val old = c.getSharedPreferences("log", 0).getString("l", "") ?: ""
        c.getSharedPreferences("log", 0).edit().putString("l", ("$t $msg\n$old").take(3000)).apply()
    }
    fun readLog(c: Context): String = c.getSharedPreferences("log", 0).getString("l", "") ?: ""
    fun clearLog(c: Context) = c.getSharedPreferences("log", 0).edit().clear().apply()
}
