package com.example.keymapper

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import kotlin.math.hypot

/** See-through full-screen editor drawn over the game. */
class EditorView(ctx: Context, private val onClose: () -> Unit) : View(ctx) {
    private enum class Mode { MOVE, WAIT_KEY, STICK1, STICK2 }
    private var mode = Mode.MOVE
    private var cx = -1f; private var cy = -1f
    private var pending = Pair(0f, 0f)
    private var p1 = Pair(0f, 0f)
    private var msg = ""
    private val d = ctx.resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val loc = IntArray(2)
    private val labels = listOf("OK / A|Place tap", "X|Set joystick", "Y|Delete", "Back|Close")

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) { if (cx < 0) { cx = w / 2f; cy = h / 2f } }

    fun nudge(dx: Float, dy: Float) {
        cx = (cx + dx).coerceIn(0f, width.toFloat()); cy = (cy + dy).coerceIn(0f, height.toFloat()); invalidate()
    }

    private fun here(): Pair<Float, Float> { getLocationOnScreen(loc); return Pair(loc[0] + cx, loc[1] + cy) }

    private fun ok() {
        val pt = here()
        when (mode) {
            Mode.MOVE -> { pending = pt; mode = Mode.WAIT_KEY; msg = "" }
            Mode.STICK1 -> { p1 = pt; mode = Mode.STICK2 }
            Mode.STICK2 -> {
                Store.saveStick(context, p1.first, p1.second, hypot(pt.first - p1.first, pt.second - p1.second))
                mode = Mode.MOVE; msg = "Joystick saved"
            }
            else -> {}
        }
        invalidate()
    }

    private fun delete() {
        val (x, y) = here(); val m = Store.load(context)
        val near = m.entries.minByOrNull { hypot(it.value.first - x, it.value.second - y) }
        if (near != null && hypot(near.value.first - x, near.value.second - y) < 80 * d) {
            m.remove(near.key); Store.save(context, m); msg = "Deleted ${name(near.key)}"
        } else msg = "Nothing here to delete (move the crosshair onto a green circle)"
        invalidate()
    }

    private fun back() { if (mode != Mode.MOVE) { mode = Mode.MOVE; msg = "" ; invalidate() } else onClose() }

    private fun name(code: Int) = KeyEvent.keyCodeToString(code).removePrefix("KEYCODE_")

    fun handleKey(e: KeyEvent) {
        val code = e.keyCode
        if (mode == Mode.WAIT_KEY) {
            if (code == KeyEvent.KEYCODE_BACK) { back(); return }
            val m = Store.load(context); m[code] = pending; Store.save(context, m)
            mode = Mode.MOVE; msg = "Saved: ${name(code)} now taps here"; invalidate(); return
        }
        val step = 8f * d / 2f + minOf(e.repeatCount, 30) * 2f * d
        when (code) {
            KeyEvent.KEYCODE_DPAD_LEFT -> nudge(-step, 0f)
            KeyEvent.KEYCODE_DPAD_RIGHT -> nudge(step, 0f)
            KeyEvent.KEYCODE_DPAD_UP -> nudge(0f, -step)
            KeyEvent.KEYCODE_DPAD_DOWN -> nudge(0f, step)
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_BUTTON_A -> if (e.repeatCount == 0) ok()
            KeyEvent.KEYCODE_BUTTON_X, KeyEvent.KEYCODE_S -> { mode = Mode.STICK1; msg = ""; invalidate() }
            KeyEvent.KEYCODE_BUTTON_Y, KeyEvent.KEYCODE_DEL, KeyEvent.KEYCODE_FORWARD_DEL -> delete()
            KeyEvent.KEYCODE_BACK -> back()
        }
    }

    private fun btnRect(i: Int): RectF {
        val gap = 12 * d; val w = (width - 32 * d - 3 * gap) / 4
        val l = 16 * d + i * (w + gap)
        return RectF(l, height - 16 * d - 64 * d, l + w, height - 16 * d)
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        if (ev.action == MotionEvent.ACTION_UP) {
            val i = (0..3).firstOrNull { btnRect(it).contains(ev.x, ev.y) }
            when (i) {
                0 -> ok(); 1 -> { mode = Mode.STICK1; msg = ""; invalidate() }
                2 -> delete(); 3 -> back()
                else -> { cx = ev.x; cy = ev.y; invalidate() }
            }
        }
        return true
    }

    private fun tag(c: Canvas, text: String, x: Float, y: Float, color: Int) {
        paint.style = Paint.Style.FILL; paint.textSize = 14 * d; paint.textAlign = Paint.Align.CENTER
        val w = paint.measureText(text)
        paint.color = 0xDD000000.toInt()
        c.drawRoundRect(x - w / 2 - 6 * d, y - 15 * d, x + w / 2 + 6 * d, y + 6 * d, 6 * d, 6 * d, paint)
        paint.color = color; c.drawText(text, x, y, paint)
    }

    private fun text(c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int, bold: Boolean = false) {
        paint.style = Paint.Style.FILL; paint.textAlign = Paint.Align.LEFT; paint.textSize = size * d
        paint.isFakeBoldText = bold; paint.color = color; c.drawText(s, x, y, paint); paint.isFakeBoldText = false
    }

    override fun onDraw(c: Canvas) {
        c.drawColor(0x33000000) // light tint, game stays visible
        getLocationOnScreen(loc)
        val m = Store.load(context)

        // Existing taps: green circles with the button name
        m.forEach { (code, p) ->
            val x = p.first - loc[0]; val y = p.second - loc[1]
            paint.style = Paint.Style.FILL; paint.color = 0x5500E676; c.drawCircle(x, y, 26 * d, paint)
            paint.style = Paint.Style.STROKE; paint.strokeWidth = 3 * d; paint.color = 0xFF00E676.toInt(); c.drawCircle(x, y, 26 * d, paint)
            tag(c, name(code), x, y + 46 * d, 0xFF00E676.toInt())
        }
        // Joystick area: orange circle
        Store.stick(context)?.let { s ->
            val x = s[0] - loc[0]; val y = s[1] - loc[1]
            paint.style = Paint.Style.STROKE; paint.strokeWidth = 3 * d; paint.color = 0xFFFFA726.toInt()
            c.drawCircle(x, y, s[2], paint); c.drawCircle(x, y, 6 * d, paint)
            tag(c, "JOYSTICK", x, y - s[2] - 10 * d, 0xFFFFA726.toInt())
        }
        // Stick step 2 preview
        if (mode == Mode.STICK2) {
            val x = p1.first - loc[0]; val y = p1.second - loc[1]
            paint.style = Paint.Style.STROKE; paint.color = 0xFFFFA726.toInt()
            c.drawCircle(x, y, hypot(cx - x, cy - y), paint)
        }
        // Pending spot
        if (mode == Mode.WAIT_KEY) {
            paint.style = Paint.Style.STROKE; paint.color = 0xFFFFEB3B.toInt()
            c.drawCircle(pending.first - loc[0], pending.second - loc[1], 26 * d, paint)
        }
        // Crosshair
        paint.style = Paint.Style.STROKE; paint.strokeWidth = 3 * d; paint.color = 0xFF00E5FF.toInt()
        c.drawLine(cx - 34 * d, cy, cx + 34 * d, cy, paint); c.drawLine(cx, cy - 34 * d, cx, cy + 34 * d, paint)
        c.drawCircle(cx, cy, 12 * d, paint)

        // Top panel
        paint.style = Paint.Style.FILL; paint.color = 0xE6101820.toInt()
        c.drawRoundRect(16 * d, 16 * d, width - 16 * d, 112 * d, 14 * d, 14 * d, paint)
        text(c, "KEY MAPPER   |   Profile: ${Store.current(context)}   |   ${m.size} taps", 32 * d, 46 * d, 18f, 0xFFFFFFFF.toInt(), true)
        val status = when (mode) {
            Mode.MOVE -> "Move the blue crosshair over a game button with the arrow keys, then press OK."
            Mode.WAIT_KEY -> "Now press the controller button for this spot.  (Back = cancel)"
            Mode.STICK1 -> "JOYSTICK 1/2: move to the CENTER of the on-screen stick, press OK."
            Mode.STICK2 -> "JOYSTICK 2/2: move to the OUTER EDGE of the stick, press OK."
        }
        text(c, status, 32 * d, 74 * d, 16f, 0xFF80DEEA.toInt())
        if (msg.isNotEmpty()) text(c, msg, 32 * d, 100 * d, 15f, 0xFFFFEB3B.toInt())

        // Bottom buttons
        for (i in 0..3) {
            val r = btnRect(i); val (key, label) = labels[i].split("|")
            paint.style = Paint.Style.FILL; paint.color = 0xE6101820.toInt(); c.drawRoundRect(r, 12 * d, 12 * d, paint)
            paint.textAlign = Paint.Align.CENTER
            paint.textSize = 14 * d; paint.color = 0xFF80DEEA.toInt(); c.drawText(key, r.centerX(), r.top + 24 * d, paint)
            paint.textSize = 18 * d; paint.color = 0xFFFFFFFF.toInt(); c.drawText(label, r.centerX(), r.top + 50 * d, paint)
        }
    }
}
