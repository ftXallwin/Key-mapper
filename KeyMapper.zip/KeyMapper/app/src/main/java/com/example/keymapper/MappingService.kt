package com.example.keymapper

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.accessibilityservice.GestureDescription.StrokeDescription
import android.graphics.Path
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.accessibility.AccessibilityEvent
import kotlin.math.hypot

class MappingService : AccessibilityService() {
    private var stroke: StrokeDescription? = null
    private var lastX = 0f; private var lastY = 0f
    private var tx = 0f; private var ty = 0f
    private var busy = false

    override fun onServiceConnected() {
        // Joystick events for accessibility services need Android 14 (API 34)+
        if (android.os.Build.VERSION.SDK_INT >= 34) {
            serviceInfo = serviceInfo.apply { motionEventSources = InputDevice.SOURCE_JOYSTICK }
        }
    }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onKeyEvent(e: KeyEvent): Boolean {
        val t = Store.load(this)[e.keyCode] ?: return false
        if (e.action == KeyEvent.ACTION_DOWN && e.repeatCount == 0) {
            val p = Path().apply { moveTo(t.first, t.second) }
            dispatchGesture(GestureDescription.Builder().addStroke(StrokeDescription(p, 0, 60)).build(), null, null)
        }
        return true
    }

    override fun onMotionEvent(ev: MotionEvent) {
        val s = Store.stick(this) ?: return
        val x = ev.getAxisValue(MotionEvent.AXIS_X)
        val y = ev.getAxisValue(MotionEvent.AXIS_Y)
        if (hypot(x, y) < 0.25f) { release(); return }
        tx = s[0] + x * s[2]; ty = s[1] + y * s[2]
        if (stroke == null) { lastX = s[0]; lastY = s[1] }
        if (!busy) step(true)
    }

    // Moves the held finger toward the latest target in 40ms slices.
    private fun step(hold: Boolean) {
        val p = Path().apply { moveTo(lastX, lastY); lineTo(tx, ty) }
        val s = stroke?.continueStroke(p, 0, 40, hold) ?: StrokeDescription(p, 0, 40, hold)
        stroke = if (hold) s else null
        lastX = tx; lastY = ty; busy = true
        dispatchGesture(GestureDescription.Builder().addStroke(s).build(),
            object : GestureResultCallback() {
                override fun onCompleted(g: GestureDescription?) { busy = false }
                override fun onCancelled(g: GestureDescription?) { busy = false; stroke = null }
            }, null)
    }

    private fun release() { if (stroke != null && !busy) step(false) }
}
