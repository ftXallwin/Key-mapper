package com.example.keymapper

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.accessibilityservice.GestureDescription.StrokeDescription
import android.graphics.Outline
import android.graphics.Path
import android.graphics.PixelFormat
import android.view.Gravity
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.ImageView
import kotlin.math.hypot

class MappingService : AccessibilityService() {
    private var stroke: StrokeDescription? = null
    private var lastX = 0f; private var lastY = 0f
    private var tx = 0f; private var ty = 0f
    private var busy = false
    private lateinit var wm: WindowManager
    private var icon: ImageView? = null
    private var editor: EditorView? = null
    private val hotkeys = setOf(KeyEvent.KEYCODE_BUTTON_SELECT, KeyEvent.KEYCODE_F8, KeyEvent.KEYCODE_PROG_RED)

    override fun onServiceConnected() {
        try {
            if (android.os.Build.VERSION.SDK_INT >= 34) {
                serviceInfo = serviceInfo.apply { motionEventSources = InputDevice.SOURCE_JOYSTICK }
            }
        } catch (t: Throwable) {}
        try { wm = getSystemService(WINDOW_SERVICE) as WindowManager } catch (t: Throwable) {}
        try { addIcon() } catch (t: Throwable) {}
    }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onDestroy() { closeEditor(); icon?.let { try { wm.removeView(it) } catch (e: Exception) {} }; super.onDestroy() }

    // ---- Floating icon + editor ----
    private fun addIcon() {
        val d = resources.displayMetrics.density
        val size = (52 * d).toInt()
        val v = ImageView(this).apply {
            setImageResource(R.drawable.ic_launcher); alpha = 0.7f; scaleType = ImageView.ScaleType.CENTER_CROP
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, o: Outline) { o.setOval(0, 0, view.width, view.height) }
            }
            clipToOutline = true
        }
        val lp = WindowManager.LayoutParams(size, size, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = (30 * d).toInt(); y = (200 * d).toInt() }
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        v.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> { sx = ev.rawX; sy = ev.rawY; ox = lp.x; oy = lp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    if (hypot(ev.rawX - sx, ev.rawY - sy) > 12 * d) moved = true
                    if (moved) { lp.x = ox + (ev.rawX - sx).toInt(); lp.y = oy + (ev.rawY - sy).toInt(); wm.updateViewLayout(v, lp) }
                }
                MotionEvent.ACTION_UP -> if (!moved) toggleEditor()
            }
            true
        }
        wm.addView(v, lp); icon = v
    }

    private fun toggleEditor() { try { if (editor == null) openEditor() else closeEditor() } catch (t: Throwable) {} }

    private fun openEditor() {
        val e = EditorView(this) { closeEditor() }
        val lp = WindowManager.LayoutParams(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT)
        wm.addView(e, lp); editor = e; icon?.visibility = View.GONE
    }

    private fun closeEditor() {
        editor?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        editor = null; icon?.visibility = View.VISIBLE
    }

    // ---- Input ----
    override fun onKeyEvent(e: KeyEvent): Boolean = try { handleKey(e) } catch (t: Throwable) { false }

    private fun handleKey(e: KeyEvent): Boolean {
        val code = e.keyCode
        if (code in hotkeys) { if (e.action == KeyEvent.ACTION_DOWN && e.repeatCount == 0) toggleEditor(); return true }
        editor?.let { if (e.action == KeyEvent.ACTION_DOWN) it.handleKey(e); return true }
        val t = Store.load(this)[code] ?: return false
        if (e.action == KeyEvent.ACTION_DOWN && e.repeatCount == 0) {
            val p = Path().apply { moveTo(t.first, t.second) }
            dispatchGesture(GestureDescription.Builder().addStroke(StrokeDescription(p, 0, 60)).build(), null, null)
        }
        return true
    }

    override fun onMotionEvent(ev: MotionEvent) { try { motion(ev) } catch (t: Throwable) {} }

    private fun motion(ev: MotionEvent) {
        val x = ev.getAxisValue(MotionEvent.AXIS_X)
        val y = ev.getAxisValue(MotionEvent.AXIS_Y)
        editor?.let { if (hypot(x, y) > 0.25f) it.nudge(x * 14 * resources.displayMetrics.density, y * 14 * resources.displayMetrics.density); return }
        val s = Store.stick(this) ?: return
        if (hypot(x, y) < 0.25f) { release(); return }
        tx = s[0] + x * s[2]; ty = s[1] + y * s[2]
        if (stroke == null) { lastX = s[0]; lastY = s[1] }
        if (!busy) step(true)
    }

    private fun step(hold: Boolean) {
        val p = Path().apply { moveTo(lastX, lastY); lineTo(tx, ty) }
        val s = stroke?.continueStroke(p, 0, 40, hold) ?: StrokeDescription(p, 0, 40, hold)
        stroke = if (hold) s else null
        lastX = tx; lastY = ty; busy = true
        dispatchGesture(GestureDescription.Builder().addStroke(s).build(),
            object : GestureResultCallback() {
                override fun onCompleted(g: GestureDescription?) { busy = false }
                override fun onCancelled(g: GestureDescription?) { busy = false; stroke = null }
            }, null)
    }

    private fun release() { if (stroke != null && !busy) step(false) }
}
