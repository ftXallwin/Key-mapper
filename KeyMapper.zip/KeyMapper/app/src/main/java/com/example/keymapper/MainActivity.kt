package com.example.keymapper

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.widget.*
import kotlin.math.hypot

class MainActivity : Activity() {
    private var capturing = false
    private lateinit var info: TextView

    override fun onCreate(b: Bundle?) { super.onCreate(b); showMain() }

    private fun btn(root: LinearLayout, label: String, f: () -> Unit) =
        root.addView(Button(this).apply { text = label; setOnClickListener { f() } })

    private fun showMain() {
        capturing = false
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(60, 40, 60, 40) }
        info = TextView(this).apply { textSize = 20f }
        root.addView(info)
        btn(root, "Switch profile") {
            val names = Store.profiles(this).toTypedArray()
            AlertDialog.Builder(this).setItems(names) { _, i -> Store.setCurrent(this, names[i]); showMain() }.show()
        }
        btn(root, "New profile") {
            val et = EditText(this)
            AlertDialog.Builder(this).setTitle("Profile name").setView(et)
                .setPositiveButton("Create") { _, _ -> Store.addProfile(this, et.text.toString()); showMain() }.show()
        }
        btn(root, "Delete this profile") { Store.deleteCurrent(this); showMain() }
        btn(root, "Add button mapping") { capturing = true; info.text = "Press a gamepad/keyboard button now..." }
        btn(root, "Set joystick area") {
            pick("Click the CENTER of your on-screen stick", 2) { p ->
                Store.saveStick(this, p[0].first, p[0].second, hypot(p[1].first - p[0].first, p[1].second - p[0].second))
            }
        }
        btn(root, "Clear button mappings") { Store.save(this, emptyMap()); showMain() }
        btn(root, "Open Accessibility settings") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        setContentView(ScrollView(this).apply { addView(root) })
        refresh()
    }

    private fun refresh() {
        val m = Store.load(this); val s = Store.stick(this)
        info.text = "Profile: ${Store.current(this)}\n" +
            (if (s == null) "Joystick: not set\n" else "Joystick: (${s[0].toInt()}, ${s[1].toInt()}) r=${s[2].toInt()}\n") +
            (if (m.isEmpty()) "No button mappings" else m.entries.joinToString("\n") {
                "${KeyEvent.keyCodeToString(it.key)} -> (${it.value.first.toInt()}, ${it.value.second.toInt()})" })
    }

    // Full-screen click picker: collects n clicks, then calls done.
    private fun pick(msg: String, n: Int, done: (List<Pair<Float, Float>>) -> Unit) {
        val pts = mutableListOf<Pair<Float, Float>>()
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
        setContentView(object : View(this) {
            init { setBackgroundColor(0xFF222222.toInt()) }
            override fun onTouchEvent(ev: MotionEvent): Boolean {
                if (ev.action == MotionEvent.ACTION_UP) {
                    pts.add(Pair(ev.rawX, ev.rawY))
                    if (pts.size == n) { done(pts); showMain() }
                    else Toast.makeText(context, "Now click the stick's outer EDGE", Toast.LENGTH_LONG).show()
                }
                return true
            }
        })
    }

    override fun onKeyDown(code: Int, e: KeyEvent): Boolean {
        if (capturing && code != KeyEvent.KEYCODE_BACK) {
            capturing = false
            pick("Click where this button should tap", 1) { p ->
                val m = Store.load(this); m[code] = p[0]; Store.save(this, m)
            }
            return true
        }
        return super.onKeyDown(code, e)
    }
}
