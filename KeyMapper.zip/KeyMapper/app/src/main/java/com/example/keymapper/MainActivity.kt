package com.example.keymapper

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Paint
import android.os.Bundle
import android.provider.Settings
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.widget.*
import kotlin.math.hypot

class MainActivity : Activity() {
    private var capturing = false
    private lateinit var info: TextView

    override fun onCreate(b: Bundle?) { super.onCreate(b); showMain() }

    private fun btn(root: LinearLayout, label: String, f: () -> Unit) =
        root.addView(Button(this).apply { text = label; setOnClickListener { f() } })

    private fun showMain() {
        capturing = false
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(60, 40, 60, 40) }
        root.addView(TextView(this).apply { textSize = 18f; setPadding(0, 0, 0, 30)
            text = "HOW TO USE\n1. Turn on Key Mapper in Accessibility settings.\n2. Open your game.\n3. Press SELECT on your gamepad (or F8 / the red remote button), or tap the floating icon, to open the see-through editor.\n\nThe buttons below still work as a backup." })
        info = TextView(this).apply { textSize = 20f }
        root.addView(info)
        btn(root, "Switch profile") {
            val names = Store.profiles(this).toTypedArray()
            AlertDialog.Builder(this).setItems(names) { _, i -> Store.setCurrent(this, names[i]); showMain() }.show()
        }
        btn(root, "New profile") {
            val et = EditText(this)
            AlertDialog.Builder(this).setTitle("Profile name").setView(et)
                .setPositiveButton("Create") { _, _ -> Store.addProfile(this, et.text.toString()); showMain() }.show()
        }
        btn(root, "Delete this profile") { Store.deleteCurrent(this); showMain() }
        btn(root, "Add button mapping") { capturing = true; info.text = "Press a gamepad/keyboard button now..." }
        btn(root, "Set joystick area") {
            pick(listOf("Move the crosshair to the CENTER of the on-screen stick, press OK",
                        "Now move to the stick's outer EDGE, press OK")) { p ->
                Store.saveStick(this, p[0].first, p[0].second, hypot(p[1].first - p[0].first, p[1].second - p[0].second))
            }
        }
        btn(root, "Clear button mappings") { Store.save(this, emptyMap()); showMain() }
        btn(root, "Clear log") { Store.clearLog(this); showMain() }
        btn(root, "Open Accessibility settings") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        setContentView(ScrollView(this).apply { addView(root) })
        refresh()
    }

    private fun refresh() {
        val m = Store.load(this); val s = Store.stick(this)
        info.text = "LOG (newest first):\n" + Store.readLog(this).ifEmpty { "(empty - service has never started)" } + "\n\nProfile: ${Store.current(this)}\n" +
            (if (s == null) "Joystick: not set\n" else "Joystick: (${s[0].toInt()}, ${s[1].toInt()}) r=${s[2].toInt()}\n") +
            (if (m.isEmpty()) "No button mappings" else m.entries.joinToString("\n") {
                "${KeyEvent.keyCodeToString(it.key)} -> (${it.value.first.toInt()}, ${it.value.second.toInt()})" })
    }

    // Capture the next key press before any view can swallow it.
    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (capturing && e.action == KeyEvent.ACTION_DOWN && e.keyCode != KeyEvent.KEYCODE_BACK) {
            capturing = false
            val code = e.keyCode
            pick(listOf("Move the crosshair with the arrow keys to where this button should tap, then press OK")) { p ->
                val m = Store.load(this); m[code] = p[0]; Store.save(this, m)
            }
            return true
        }
        return super.dispatchKeyEvent(e)
    }

    // Crosshair picker: arrow keys move it (hold to speed up), OK / A confirms. Touch or mouse also works.
    private fun pick(prompts: List<String>, done: (List<Pair<Float, Float>>) -> Unit) {
        setContentView(PickView(this, prompts, done))
    }

    inner class PickView(ctx: Context, private val prompts: List<String>,
                         private val done: (List<Pair<Float, Float>>) -> Unit) : View(ctx) {
        private val pts = mutableListOf<Pair<Float, Float>>()
        private var cx = -1f; private var cy = -1f
        private val paint = Paint().apply { strokeWidth = 4f; textSize = 36f; isAntiAlias = true }

        init { isFocusable = true; isFocusableInTouchMode = true; post { requestFocus() } }

        override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
            if (cx < 0) { cx = w / 2f; cy = h / 2f }
        }

        override fun onDraw(c: Canvas) {
            c.drawColor(0xFF222222.toInt())
            paint.color = 0xFFFFFFFF.toInt()
            c.drawText(prompts[pts.size], 40f, 70f, paint)
            c.drawText("x=${cx.toInt()}  y=${cy.toInt()}   (Back = cancel)", 40f, 120f, paint)
            paint.color = 0xFF00E5FF.toInt()
            c.drawLine(cx - 40, cy, cx + 40, cy, paint)
            c.drawLine(cx, cy - 40, cx, cy + 40, paint)
            c.drawCircle(cx, cy, 14f, paint.apply { style = Paint.Style.STROKE })
            if (pts.isNotEmpty()) {
                paint.color = 0xFFFF5252.toInt()
                val loc = IntArray(2); getLocationOnScreen(loc)
                c.drawCircle(pts[0].first - loc[0], pts[0].second - loc[1], 14f, paint)
            }
        }

        private fun confirm() {
            val loc = IntArray(2); getLocationOnScreen(loc)
            pts.add(Pair(loc[0] + cx, loc[1] + cy))
            if (pts.size == prompts.size) { done(pts); showMain() } else invalidate()
        }

        override fun onKeyDown(code: Int, e: KeyEvent): Boolean {
            val step = 8f + minOf(e.repeatCount, 30) * 4f
            when (code) {
                KeyEvent.KEYCODE_DPAD_LEFT -> cx -= step
                KeyEvent.KEYCODE_DPAD_RIGHT -> cx += step
                KeyEvent.KEYCODE_DPAD_UP -> cy -= step
                KeyEvent.KEYCODE_DPAD_DOWN -> cy += step
                KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_BUTTON_A -> {
                    if (e.repeatCount == 0) confirm(); return true
                }
                KeyEvent.KEYCODE_BACK -> { showMain(); return true }
                else -> return super.onKeyDown(code, e)
            }
            cx = cx.coerceIn(0f, width.toFloat()); cy = cy.coerceIn(0f, height.toFloat())
            invalidate(); return true
        }

        override fun onTouchEvent(ev: MotionEvent): Boolean {
            if (ev.action == MotionEvent.ACTION_UP) { cx = ev.x; cy = ev.y; confirm() }
            return true
        }
    }
}
